# Phase 6 closure baseline

Review date: 2026-09-10. Status: **OPEN — SOFTWARE REGRESSION AND HIL PREPARATION; NOT PHASE ACCEPTANCE**.

This record consolidates the remaining acceptance work. Historical failures
remain in their original evidence directories. A software or simulated-bus
pass does not close a physical-drive requirement.

## Requirement disposition

| Requirement | Current evidence | Closure disposition |
|---|---|---|
| P6.1 inventory | 119 successful values; first capture explicitly accepted | PASS within documented identity scope; identity count contradiction retained |
| P6.2 codecs | Host, sanitizer and Debug cross evidence | PASS for pure semantics; no physical packed-half mapping inferred |
| P6.3 bounded transmit gate | Exact frame gate and managed-vcan rejection tests | PASS for software authorization; hardware requires a separate preflight |
| P6.4 zero-target transitions | Normal sequence and post-enable SIGTERM dual captures | PASS |
| P6.5 positive independent targets | Both channels, +5 rpm, separate three-second trials | PASS: :01 left and :02 right; reverse direction not tested |
| Zero command, NMT Stop, Shutdown, Disable Voltage | P6.5/P6.6 dual captures and operator observations | PASS only for recorded unloaded trials |
| Quick Stop with existing 0x605A=5 | 203 matching physical frames and operator confirmation, 2026-09-10 | PASS for the two-second +5 rpm right-axis trial; final cleanup zero reverified in 442.289 ms |
| Heartbeat/TPDO staleness and EMCY | Managed-vcan negative cases | Software PASS; physical stimulus/evidence pending |
| SIGTERM during motion | Zero-target physical SIGTERM and simulated interruption | Moving-drive physical case pending |
| Controlled interface loss/reopen | Software link-loss and Phase 4/5 observation recovery | Phase 6 moving-drive protection pending; observation recovery must not rearm |
| Drive communication watchdog 0x2000 | Attempt 2: operator confirms stop then restart without renewed nonzero/enable request, 182 matching frames. Repeat 3: both wheels observed stationary, so dynamic result inconclusive despite 166 matching frames and cleanup pass | Non-latched behavior retained; software now requires measured motion before loss stimuli. Physical validation of the correction, exact timing, two-frame RX discrepancy and safe traffic resumption remain OPEN |
| Emergency inputs, brake outputs, fault reset, electrical bus-off | Configuration values and incidental operator observations | OPEN applicability decisions; none may be silently marked PASS or not applicable |
| Normal/P5.6 isolation and final cross regression | See software evidence below | Required again on the final source after remaining implementation |

## Packed-feedback disposition

The accepted left and right trials show TPDO1 packed velocity staying zero
while an independent SDO velocity and physical observation show movement.
Zero packed velocity is therefore **not accepted as proof of standstill or
of an uncommanded wheel being stationary**. The executor retains independent
0x606C:01/02 readbacks for zero preconditions and cleanup; its packed TPDO
check during motion is only an additional rejection check, not independently
qualified supervision of the other wheel. Operator supervision and the
independent power cut remain necessary for the bounded raised-wheel trials.

Do not relabel neutral status/fault halves, enable packed targets, or claim
production feedback eligibility from these trials. Resolution requires an
authorized comparison of the current 0x1A00 mapping and 0x606C:03 SDO value
against TPDO1 bytes and independent velocities during the same interval.
If packed feedback is excluded from a later production design, that design
must provide and validate independent feedback freshness and uncommanded-axis
supervision; a documentation exclusion alone cannot close this requirement.

## Remaining physical order

1. Reconfirm the current raised-wheel fixture, operator, independent power
   cut, and actual X0/X1 and B0/B1 wiring.
2. Quick Stop without changing 0x605A is complete; preserve its first-zero
   and final-cleanup timings separately because feedback rebounded.
3. Resolve packed-feedback evidence with an exact authorized read/motion plan.
4. Qualify the watchdog first with a bounded, reversible 0x2000 value and
   passive observers. The current executor does not authorize 0x2000 writes;
   an exact typed operation and simulated failure/restore tests are required
   before that trial. A readback requester during loss can refresh the
   unknown watchdog and invalidate the experiment.
5. Only after an independent drive stop path is proven, qualify physical
   heartbeat/TPDO loss, moving SIGTERM and interface loss/reopen with separate
   stimuli. No automatic retry, restart into motion, or inferred rearm.
6. Record applicable emergency/brake/fault tests or explicit equipment-based
   not-applicable decisions. Loaded behavior remains outside Phase 6.
7. Run final regression on the resulting source and review accepted residuals.

## Software evidence

Evidence directory: `evidence/p6_7_20260910_closure/`.

- Fresh GCC 13.3 Debug qualification build: 88/88 steps. Narrow tests: 21/21;
  full suite: 48/48, including managed vcan.
- Fresh LLVM 22.1.8 ASan/UBSan build: 88/88; full suite: 48/48.
- Fresh default-OFF Host Debug: 28/28; normal Host Release: 28/28;
  P5.6 commissioning regression: 36/36. No skipped tests in these final runs.
- Normal/P5.6 ELF symbol and executable isolation checks pass. Release
  qualification and simultaneous P5.6/qualification configure guards reject
  their forbidden configurations as expected.
- Locked, network-disabled RK3588 Debug and Release builds each pass 46/46
  with interpreter, dependency, symbol-version and RPATH audits. The separate
  Debug qualification build passes 69/69 and its ELF audit passes.
- The initial sandbox test failed local socket operations and skipped vcan;
  the same narrow tests passed outside the sandbox. Preserve both logs.
- Format checks use repository style for the new files and the existing
  two-space LLVM style for cia402.cpp. The first blanket-style check was not
  an applicable formatting check for that legacy file.
- The first clang-tidy invocation could not consume Clang module-map response
  files. The GCC compilation-database run is the applicable analyzer result;
  preserve the failed invocation for traceability.
  The successful GCC-database analysis reports three reviewed advisories:
  adjacent named duration arguments at the private stop helper, and the two
  existing checked-by-caller Result::value accessors. No analyzer error remains.

## Clean-source provenance

The separate local checkout `out/p67-release-review` contains review commit
`e8c6c16e3dd4e16ec70f6b8f11de694966736b02`. Its parent is the original
`1d1314d25269d38f9679cd2c15e23df65afcd2a4`. The main checkout was not committed
or reset. Both upstream submodules retain their pinned revisions and are clean.

The original dirty-worktree snapshot and the clean committed review snapshot
have the identical archive SHA-256
`1c5c25967de3c4d8aa89c75f95bb28f9cac81f84b28889c2706f810e5ab2f09b`
(1490 files). This closes the deferred Release compilation check for that
source, without weakening the clean-source gate. It does not constitute
final Phase 6 acceptance or a production release. Later documentation updates
and remaining physical implementation still require final integration.

The first cross attempt could not access Docker inside the sandbox. The next
attempt exposed missing active-submodule registration in the new local clone;
registration was corrected, recursive source selection verified, and both
final builds passed. All attempt logs are retained. No upstream source or
build safety check was changed.

Qualification ELF SHA-256:
`6193a8df071c92c766189d9871094aa1dcbfbb88e82e0c8e1acb5dfa7acd86ba`.
It is staged locally under `out/staging/p66-quick-stop-6193a8df071c/`;
deployment and the authorized Quick Stop physical trial subsequently passed.
See `P6_6_QUICK_STOP_HIL_PREPARATION.md` for the 203-frame evidence and
operator confirmation. The preceding capture-only preflight failure had zero
CAN TX and did not consume a physical motion attempt.

No new physical operation is authorized by this baseline. Phase 6 remains
open until the unresolved physical requirements and final evidence gate pass.

## Corrected watchdog trial 4 — 2026-09-10

The corrected artifact verified initial independent left velocity 0 and right
velocity raw 52 in 2.317 ms before a 1503.002 ms TX-free interval. Post-silence
velocity reads and final cleanup were zero, with no sampled rebound. The operator
corrected the initial stationary report: the right wheel rotated counter-clockwise
viewed from its right side, then stopped; the left stayed stationary, with normal
brake behavior and sound. Exact stop phase and absence of restart were not
explicitly confirmed. Both captures match all 170 frames; kernel packet and byte
deltas reconcile exactly (58 TX, 112 RX). Cleanup, volatile restoration, adapter
shutdown and process postflight pass. See
evidence/p6_6_20260910_watchdog_trial_4/RESULT.md. Exact watchdog stop timing and
traffic-resumption safety remain open; trial 2's observed restart remains
applicable. Physical heartbeat/TPDO-loss qualification and Phase 6 remain open.

## Manual speed-first TPDO verification — 2026-09-10

The operator-authorized manual-only trial configured the supplied packed-speed-
first/status-second TPDO1 order without target or controlword writes. The right
wheel was turned by hand in both directions; the left remained stationary with
normal brake/sound. Both captures match2042 frames, including1205 TPDO1 samples
at median50.007ms. Right raw feedback spans-1036..920 and returns to zero;
independent SDO speed also changes. Left raw excursions-5..4 in19 samples remain
unexplained despite observed stationarity. Kernel RX has an unresolved excess of
3 packets/24 bytes; no CAN errors/drops occurred. Original mapping and heartbeat
were restored with exact readbacks. This supports manual feedback availability,
not enabled-drive watchdog timing or perfect axis isolation. See
[manual trial](evidence/p6_6_20260910_manual_tpdo_trial_1/RESULT.md).
