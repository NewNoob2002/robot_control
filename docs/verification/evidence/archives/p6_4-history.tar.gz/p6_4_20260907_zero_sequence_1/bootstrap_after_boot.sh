#!/bin/sh
# Observe one real node-1 boot and submit one authorized volatile heartbeat write.
# Run under timeout; requires a live qualification owner, unchanged can0 fixture,
# and independent captures. No retries, enable/NMT commands, or persistent writes.
set -eu
stdbuf -oL candump -L can0 | {
while IFS= read -r frame; do
    case "$frame" in
        *" can0 701#00")
            if ! pgrep -f -x '/tmp/robot-control-qualifications/p64-ac24cc41ccb2/robot-control-zlac-qualification --interface can0 --zero-sequence' >/dev/null; then
                echo 'bootstrap_rejected: qualification owner absent' >&2
                exit 1
            fi
            printf 'bootstrap_actual_boot %s\n' "$frame"
            cansend can0 601#2B171000E8030000
            echo 'bootstrap_submitted_once: require independent 0x581 acknowledgement'
            exit 0
            ;;
    esac
done
echo 'bootstrap_rejected: capture ended without actual boot' >&2
exit 1
}
