"""Check the boot-trigger helper without sockets, hardware, or CAN transmission."""
import os
from pathlib import Path
import subprocess
import tempfile

helper = Path(__file__).with_name("bootstrap_after_boot.sh")
subprocess.run(["sh", "-n", str(helper)], check=True)
cases = [
    ("ordinary", "(1) can0 701#7F\n", "0", "0", 0, False),
    ("wrong_node", "(1) can0 702#00\n", "0", "0", 0, False),
    ("extended", "(1) can0 00000701#00\n", "0", "0", 0, False),
    ("wrong_width", "(1) can0 701#0000\n", "0", "0", 0, False),
    ("once", "(1) can0 701#00\n(2) can0 701#00\n", "0", "0", 1, True),
    ("owner_absent", "(1) can0 701#00\n", "1", "0", 0, False),
    ("send_failure", "(1) can0 701#00\n", "0", "1", 1, False),
]
with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    for name, body in {
        "candump": 'cat "$BOOT_INPUT"',
        "pgrep": 'exit "$OWNER_EXIT"',
        "cansend": 'echo "$*" >> "$SEND_LOG"; exit "$SEND_EXIT"',
    }.items():
        tool = root / name
        tool.write_text("#!/bin/sh\n" + body + "\n")
        tool.chmod(0o755)
    for name, frames, owner_exit, send_exit, count, success in cases:
        capture = root / "input"
        sent = root / "sent"
        capture.write_text(frames)
        sent.write_text("")
        env = dict(os.environ, PATH=str(root) + os.pathsep + os.environ["PATH"],
                   BOOT_INPUT=str(capture), SEND_LOG=str(sent), OWNER_EXIT=owner_exit,
                   SEND_EXIT=send_exit)
        result = subprocess.run(["sh", str(helper)], env=env, capture_output=True, text=True, timeout=2)
        assert (result.returncode == 0) == success, (name, result)
        assert sent.read_text().splitlines() == ["can0 601#2B171000E8030000"] * count, name
        assert ("bootstrap_submitted_once" in result.stdout) == success, name
        print(name, "PASS")
