# Normal sequence attempt 1 — startup coordination blocked

Fixture declaration completed by the operator: both wheels suspended and
unloaded, wiring unchanged, mechanical brakes installed, independent power
disconnect available. Brake-output polarity remains unproven.

Executor started 07:14:45 UTC with a 60-second boot/heartbeat bound. Operator
power-on produced real 0x701/00 at 1788765340.308333 (07:15:40.308 UTC).
The process timed out at 07:15:45 before a heartbeat bootstrap could be
submitted through another tool call. No bootstrap, NMT, drive download or
enable occurred. This is startup coordination failure, not a drive response
timeout or a failed CiA402 transition. No automatic retry was performed.

The 300-second JCAN call hit the client tools/call deadline. Its completed
server-side evidence was recovered read-only from
20260907T071828.682109Z-1788765508682156163-capture.json: ok=true,
300000.491 ms, exactly one 0x701/00, zero drops/warnings. Subsequent
periodic_list reported no active/recent tasks and no session cleanup error.
Both raw captures therefore contain the real boot; the client timeout is
preserved as a transport limitation. Target capture ended with timeout 124
and executor exited 1. No active sequence started.

Next-session preparation uses bootstrap_after_boot.sh, run under a bound on
RK3588. It matches only an actual standard node-1 boot, verifies the exact
qualification owner command is alive, submits the single authorized heartbeat
configuration, then exits. Seven hardware-free checks in test_bootstrap.py
passed: ordinary heartbeat, wrong node, extended ID, wrong width, duplicate
boot (one send), absent owner and send failure. A test-string quoting error
was corrected before checks passed; no helper was run on hardware yet.
No qualification-library, gate or ELF change was made. Next JCAN window will
be shorter than the 300-second client deadline.
