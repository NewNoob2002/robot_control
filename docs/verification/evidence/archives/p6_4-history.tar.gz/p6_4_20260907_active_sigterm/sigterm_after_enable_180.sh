#!/bin/sh
# Signal the exact test owner once after dual-enabled zero-velocity feedback.
set -eu
owner='/tmp/robot-control-qualifications/p64-180-0bb8aa097a0f/robot-control-zlac-qualification --interface can0 --zero-sequence'
stdbuf -oL candump -L can0 | {
while IFS= read -r frame; do
    case "$frame" in
        *" can0 181#2714271400000000")
            owner_pid=$(pgrep -f -x "$owner") || exit 1
            case "$owner_pid" in ''|*[!0-9]*) exit 1;; esac
            [ "$owner_pid" -gt 1 ] || exit 1
            printf 'sigterm_trigger pid=%s frame=%s\n' "$owner_pid" "$frame"
            env kill -TERM "$owner_pid"
            echo 'sigterm_submitted_once'
            exit 0
            ;;
    esac
done
echo 'sigterm_rejected: enabled zero-velocity TPDO not observed' >&2
exit 1
}
