#!/bin/sh
# Trigger one process SIGTERM after the reviewed dual-enabled, zero-velocity TPDO.
# Run under timeout with independent raw capture; never sends a CAN frame.
set -eu
stdbuf -oL candump -L can0 | {
while IFS= read -r frame; do
    case "$frame" in
        *" can0 181#2714271400000000")
            owner_pid=$(pgrep -f -x '/tmp/robot-control-qualifications/p64-ac24cc41ccb2/robot-control-zlac-qualification --interface can0 --zero-sequence') || exit 1
            case "$owner_pid" in ''|*[!0-9]*) exit 1;; esac
            [ "$owner_pid" -gt 1 ] || exit 1
            printf 'sigterm_trigger pid=%s frame=%s\n' "$owner_pid" "$frame"
            env kill -TERM "$owner_pid"
            echo 'sigterm_submitted_once'
            exit 0
            ;;
    esac
done
echo 'sigterm_rejected: expected enabled zero-velocity TPDO not observed' >&2
exit 1
}
