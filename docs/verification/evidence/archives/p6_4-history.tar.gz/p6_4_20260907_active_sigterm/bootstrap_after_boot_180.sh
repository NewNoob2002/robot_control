#!/bin/sh
# Submit one authorized heartbeat write after a real node-1 boot.
set -eu
owner='/tmp/robot-control-qualifications/p64-180-0bb8aa097a0f/robot-control-zlac-qualification --interface can0 --zero-sequence'
stdbuf -oL candump -L can0 | {
while IFS= read -r frame; do
    case "$frame" in
        *" can0 701#00")
            pgrep -f -x "$owner" >/dev/null || exit 1
            printf 'bootstrap_actual_boot %s\n' "$frame"
            cansend can0 601#2B171000E8030000
            echo 'bootstrap_submitted_once'
            exit 0
            ;;
    esac
done
echo 'bootstrap_rejected: capture ended without actual boot' >&2
exit 1
}
