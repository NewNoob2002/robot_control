"""Exercise event and PID guards using fake commands, without sockets or signals."""
import os
from pathlib import Path
import subprocess
import tempfile

helper = Path(__file__).with_name("sigterm_after_enable.sh")
subprocess.run(["sh", "-n", str(helper)], check=True)
enabled = "(1) can0 181#2714271400000000\n"
cases = [
    ("heartbeat", "(1) can0 701#7F\n", "424242", "0", False),
    ("switched_on", "(1) can0 181#2314231400000000\n", "424242", "0", False),
    ("nonzero_velocity", "(1) can0 181#2714271401000000\n", "424242", "0", False),
    ("extended", "(1) can0 00000181#2714271400000000\n", "424242", "0", False),
    ("once", enabled + enabled, "424242", "0", True),
    ("owner_absent", enabled, "", "1", False),
    ("multiple_owners", enabled, "424242\n424243", "0", False),
    ("pid_zero", enabled, "0", "0", False),
]
with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    for name, body in {
        "candump": 'cat "$FRAME_INPUT"',
        "pgrep": 'echo "$OWNER_PID"; exit "$OWNER_EXIT"',
        "kill": 'echo "$*" >> "$SIGNAL_LOG"',
    }.items():
        tool = root / name
        tool.write_text("#!/bin/sh\n" + body + "\n")
        tool.chmod(0o755)
    for name, frames, owner_pid, owner_exit, success in cases:
        capture, signals = root / "input", root / "signals"
        capture.write_text(frames)
        signals.write_text("")
        env = dict(os.environ, PATH=str(root) + os.pathsep + os.environ["PATH"],
                   FRAME_INPUT=str(capture), SIGNAL_LOG=str(signals),
                   OWNER_PID=owner_pid, OWNER_EXIT=owner_exit)
        result = subprocess.run(["sh", str(helper)], env=env, capture_output=True, text=True, timeout=2)
        assert (result.returncode == 0) == success, (name, result)
        assert signals.read_text().splitlines() == (["-TERM 424242"] if success else []), name
        print(name, "PASS")
