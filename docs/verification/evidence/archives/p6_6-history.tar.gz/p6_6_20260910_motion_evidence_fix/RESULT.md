# Require measured motion before communication-loss qualification

The operator observed both wheels stationary during watchdog repeat 3.
The old executor required a +5 target readback but did not require an independent
nonzero measured velocity before silence. It could consequently return success
when the wheel never moved. The repeat is dynamically inconclusive, not a
physical watchdog-stop pass. Attempt 2's separately confirmed stop/restart
observation remains valid for that attempt.

A managed-vcan regression reproduced this false success in all three shared
communication-loss operations before changing the implementation; see
red_stationary_case.log. The common setup now reads 0x606C:01 and :02 after
the 200 ms lead and before silence or feedback suppression. Both reads share
a 100 ms deadline. The commanded axis must report nonzero independent velocity,
the other axis must report zero, and Operation Enabled/freshness/generation
checks must still pass. Zero commanded velocity, other-axis velocity or a
missing response aborts into the existing cleanup. No target is renewed and
no extra waiting, retry or velocity increase is used to induce motion.

The watchdog's 1500 ms quiet window begins after these two added readbacks;
wire analysis must anchor it to the actual last host frame. The selected target
remains +5 rpm on subindex 2, and the reviewed exact frame gate is unchanged.
These readbacks cannot replace physical operator observation or resolve the
packed-feedback contradiction, exact watchdog timing, non-latched restart, or
the two-frame kernel RX accounting discrepancy.

Additional managed-vcan cases cover the stationary drive, unexpected other-axis
velocity, and missing initial velocity response for each stimulus. This corrects
the acceptance check; it does not determine why the real driver stayed stationary
in repeat 3. No further hardware trial is part of this software correction.

Validation: focused gate/vcan tests pass; full Debug and LLVM 22.1.8 ASan/UBSan
each pass 51/51, including 33 communication scenarios within the vcan executable.
Default Debug/Release each pass 28/28 and P5.6 regression passes 36/36. The
pinned RK3588 Debug build and ELF/sysroot audit pass. Clang-tidy on the modified
implementation reports no errors and 15 reviewed advisories in existing paths
(const-return copies, adjacent parameters, and a guarded Result accessor).

Corrected artifact SHA256:
ea1fba5cb9fa3c6e5ede192820b4a4ddc6af575a404f46e19d8290497e7b2ea5.
The single-run watchdog wrapper is prepared in watchdog_runner/ and its frame
guard check passes. Its authorization file is absent; this artifact has not
been deployed or exercised on the physical driver. A new authorized trial is
needed to validate measured motion followed by the same bounded silence and
cleanup, including the already observed possibility of restart on resumed traffic.
