# Pre-motion attempt rejection

The first 10-second invocation returned status 2 before opening the qualification lifecycle because the previously staged ELF still exposed `--shutdown-once ... --duration-ms 1..2000`. RK3588 captured four passive `0x701#7F` heartbeats and no request frame; the JCAN 1.0 silent session likewise observed only Pre-operational heartbeats and shut down cleanly. No motion or CAN transmission occurred, so the authorized physical stimulus was not consumed.

The current source permits Shutdown durations through 10000 ms. A new host Debug build passed 44/44 tests, including managed-vcan, and the locked network-disabled RK3588 Debug qualification build completed 69/69 steps.
