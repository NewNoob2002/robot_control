# P6.6 NMT Stop Trial 1 Failure Analysis

Date: 2026-09-08.
Classification: software startup-precondition defect; physical motion stimulus was not reached.

The operator powered the drive and observed that neither wheel moved. RK3588
`candump` and the independent JCAN capture each recorded the same sole bus
frame, node-1 boot-up `0x701#00`. The qualification executor remained in
`qualification_wait_boot` and returned `qualification_ready: Connection timed
out` after 180 seconds.

The pre-correction readiness gate required both `boot_observed` and a current
heartbeat. The drive's reviewed `0x1017:00` baseline is zero, so no periodic
heartbeat followed boot-up. The executor therefore could not reach its own
temporary `0x1017:00=500 ms` setup. This was a circular prerequisite.

No `0x601`, `0x581`, NMT, controlword, target, TPDO, EMCY, or CAN error frame
appears in either raw capture. The local `CO_CANsend` permission message is the
qualification transmit gate rejecting the CANopen controller's unallowlisted
startup frame; it was not transmitted onto the physical bus. Both executor and
candump exited, `can0` remained ERROR-ACTIVE with TX/RX error counters zero,
and no drive parameter was changed by this attempt.

Operator observation recorded so far: both wheels remained stationary. The
mechanical-brake action/sound observation remains pending.
