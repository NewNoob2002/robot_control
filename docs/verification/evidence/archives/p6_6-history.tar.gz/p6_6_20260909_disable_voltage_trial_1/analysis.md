# P6.6 Disable Voltage trial 1 analysis

Result: **PHYSICAL STIMULUS AND CLEANUP OBSERVED; EXECUTOR FAIL EXPOSED STATUS DECODER DEFECT**. No retry occurred.

- RK3588 and persistent JCAN 1.0 silent capture each recorded 396 CAN frames; normalized arbitration-ID and payload sequences match exactly.
- Channel 2 held `0x60FF:02=+5 rpm` for 10001.015 ms before the sole `0x6040:00=0x0000` request `601#2B40600000000000`.
- The SDO acknowledgement followed in 0.309 ms. The first TPDO1 with raw status `0x1460` on both halves followed in 30.920 ms and repeated at 50 ms intervals.
- The shared CiA402 decoder masked bit 5 and therefore classified `0x1460` as unknown instead of Switch On Disabled; the executor timed out after two seconds and returned `qualification_dual_state_timeout`.
- Cleanup sent no `0x0006` Shutdown and no `0x000F` re-enable. It wrote and verified both targets zero, read `0x606C:01/02/03` as zero at 2009.330, 2011.327, and 2013.320 ms after Disable Voltage, entered NMT Pre-operational, restored `0x200F:00=1`, and restored `0x1017:00=0`.
- No EMCY, CAN error frame, SDO abort, prohibited frame, retry, or residual qualification process occurred. `can0` remained ERROR-ACTIVE at 500000 bit/s with zero error counters and drops. JCAN shut down cleanly and its configuration matches baseline.
- The root fix accepts state pattern `0x0060` as Switch On Disabled alongside `0x0040`, preserves the raw status, and changes the managed-vcan response to the hardware-observed `0x1460`.

The operator confirmed that the positive channel-2 command rotated the right wheel counter-clockwise, the left wheel remained stationary, both wheels stopped after Disable Voltage, and no abnormal brake action or sound occurred. The operator also clarified the vehicle-forward sign convention as left positive and right negative; for example, left `+10 rpm` and right `-10 rpm` produces forward motion at 10 rpm. A corrected physical rerun requires a new exact authorization.
