# Operator observation

Recorded: 2026-09-09 after the sole authorized Disable Voltage attempt.

- Positive channel-2 command rotated the right wheel counter-clockwise, opposite the positive left-wheel direction.
- The left wheel remained stationary throughout this trial.
- Both wheels stopped after Disable Voltage.
- No abnormal brake action or sound was observed.
- Vehicle-forward sign convention is left positive and right negative; for example, left `+10 rpm` and right `-10 rpm` produces forward motion at 10 rpm.
