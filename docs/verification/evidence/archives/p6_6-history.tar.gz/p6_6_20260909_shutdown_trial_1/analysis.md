# P6.6 Shutdown trial 1 analysis

Result: **RK3588 physical sequence PASS; independent JCAN evidence INCONCLUSIVE**.

- The RK3588 raw capture contains 196 frames from 2026-09-09T02:37:31.289149Z through 2026-09-09T02:37:34.543454Z.
- Channel 2 received `0x60FF:02=+5 rpm` for 2001.001 ms before the final `0x6040:00=0x0006` Shutdown request.
- The Shutdown SDO acknowledgement followed in 0.341 ms and TPDO status reached raw `0x1421` (both axes Ready to Switch On) in 39.318 ms.
- Channel-2 measured velocity first reached zero 318.321 ms after Shutdown. Cleanup zeroed both targets, entered NMT Pre-operational at 390.887 ms, observed `0x701#7F`, restored `0x200F:00=1`, and restored `0x1017:00=0` by 608.993 ms.
- The executor returned zero and reported `qualification_complete node=1 operation=8`. The startup `Permission denied` line is the qualification transmit gate rejecting an unsolicited CANopen stack send; the same fail-closed diagnostic is present in prior passing P6.4-P6.6 runs.
- The trace contains only the reviewed NMT, PDO, SDO request/response, and heartbeat IDs. No EMCY, CAN error frame, SDO abort, malformed frame, or cleanup residue is present.
- JCAN's 5000.736 ms capture began at 2026-09-09T02:37:17.117977Z and ended about 9.170 seconds before the RK3588 capture began. Its zero-frame result is therefore a non-overlap orchestration failure, not evidence that the physical sequence was absent.

The Shutdown behavior is demonstrated by the RK3588 capture, but P6.6 remains open until a fresh authorized retry provides an overlapping independent JCAN capture and the operator records wheel direction, stationary left wheel, and absence of abnormal brake action or sound.
