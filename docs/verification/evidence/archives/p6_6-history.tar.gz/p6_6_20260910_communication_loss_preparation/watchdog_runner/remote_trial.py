#!/usr/bin/env python3
"""Run the single authorized watchdog trial with bounded passive capture."""
import hashlib, json, os, select, signal, subprocess, sys, time
from pathlib import Path
BASE = Path('/tmp/robot-control-qualifications/p66-watchdog-a03895cb4bb6')
ELF = BASE / 'robot-control-zlac-qualification'
EXPECTED = 'a03895cb4bb60a98783e6c705a89ddd91ce7152c5dd337074360a41d176c6c2b'
assert hashlib.sha256(ELF.read_bytes()).hexdigest() == EXPECTED
assert Path('/etc/machine-id').read_text().strip() == '6923ab3301fb4a8d816759b04ec6bf0a'
for p in Path('/proc').iterdir():
    if not p.name.isdigit():
        continue
    try:
        name = (p / 'exe').resolve(strict=True).name
        assert name not in ('candump', 'cansend', 'cangen', 'robot-control-zlac-qualification', 'robot-control-canopen-commission'), (p.name, name)
    except (FileNotFoundError, PermissionError, ProcessLookupError):
        pass
OUT = BASE / 'trial_1'
OUT.mkdir(exist_ok=False)
pre = subprocess.check_output(['ip', '-j', '-details', '-statistics', 'link', 'show', 'can0'], text=True)
(OUT / 'can_preflight.json').write_text(pre)
can = json.loads(pre)[0]
assert 'UP' in can['flags'] and can['mtu'] == 16
info = can['linkinfo']['info_data']
assert info['state'] == 'ERROR-ACTIVE' and info['bittiming']['bitrate'] == 500000
stats = can.get('stats64', can.get('stats', {}))
assert all(stats[d][k] == 0 for d in ('rx', 'tx') for k in ('errors', 'dropped'))
assert all(v == 0 for v in info.get('berr_counter', {}).values())
(OUT / 'elf_sha256.txt').write_text(EXPECTED)
cap = child = None
rc = 1
started = False
try:
    with (OUT / 'rk3588_can.log').open('wb') as raw, (OUT / 'capture.stderr').open('wb') as err:
        cap = subprocess.Popen(['candump', '-ta', '-e', '-n', '10000', 'can0,0:0,#FFFFFFFF'], stdout=raw, stderr=err)
        time.sleep(0.25)
        assert cap.poll() is None, 'candump failed before readiness'
        assert any(os.readlink(p).startswith('socket:') for p in Path('/proc', str(cap.pid), 'fd').iterdir()), 'capture socket not open'
        print('CAPTURE_READY', flush=True)
        assert select.select([sys.stdin], [], [], 10)[0], 'GO deadline'
        assert sys.stdin.readline().strip() == 'GO', 'GO missing'
        assert cap.poll() is None and (OUT / 'capture.stderr').stat().st_size == 0
        (OUT / 'attempt_started.txt').write_text(str(time.time()))
        with (OUT / 'executor.log').open('wb') as log:
            child = subprocess.Popen([str(ELF), '--interface', 'can0', '--watchdog-once'], stdout=log, stderr=subprocess.STDOUT)
            started = True
            print('EXECUTOR_STARTED', flush=True)
            end = time.monotonic() + 45
            while child.poll() is None:
                assert time.monotonic() < end, 'executor deadline'
                assert cap.poll() is None, 'capture stopped during trial'
                assert (OUT / 'capture.stderr').stat().st_size == 0, 'capture warning'
                if select.select([sys.stdin], [], [], 0.02)[0]:
                    raise RuntimeError('local abort or control pipe closed: ' + sys.stdin.readline().strip())
            rc = child.returncode
            (OUT / 'executor.rc').write_text(str(rc))
        time.sleep(0.25)
finally:
    if child is not None and child.poll() is None:
        child.send_signal(signal.SIGTERM)
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            print('POWER_CUT_REQUIRED: executor did not exit after SIGTERM', flush=True)
            child.kill()
            child.wait(timeout=2)
        (OUT / 'executor.rc').write_text(str(child.returncode))
    if cap is not None and cap.poll() is None:
        cap.send_signal(signal.SIGINT)
        try:
            cap.wait(timeout=2)
        except subprocess.TimeoutExpired:
            cap.kill()
            cap.wait(timeout=2)
            rc = 1
    if cap is not None:
        (OUT / 'capture.rc').write_text(str(cap.returncode))
        if cap.returncode != 0:
            rc = 1
    post = subprocess.check_output(['ip', '-j', '-details', '-statistics', 'link', 'show', 'can0'], text=True)
    (OUT / 'can_postflight.json').write_text(post)
    (OUT / 'wrapper_result.json').write_text(json.dumps({'executor_started': started, 'wrapper_exit': rc, 'capture_stopped': cap is None or cap.poll() is not None, 'executor_stopped': child is None or child.poll() is not None}))
print('TRIAL_FINISHED rc=' + str(rc), flush=True)
sys.exit(rc)
