# Corrected Disable Voltage retry preflight

Recorded 2026-09-09 at 10:54:57 UTC.

- Corrected AArch64 ELF was copied to a new checksum-specific RK3588 `/tmp` directory; the target SHA-256 matches `833548e609bb96b1061154f3c24c21e1e0a734c20060027a40c9da4ba3354be0`.
- Target dependencies resolve, and the CLI exposes `--disable-voltage-once` with a bounded `1..10000 ms` duration.
- RK3588 `can0` is UP and ERROR-ACTIVE at 500000 bit/s with zero CAN error counters and drops.
- No qualification executor is active.
- Rust `jcan 1.0.0` self-test passed, scan selected explicit serial `207F346D5650`, and `config-get` returned `can_speed=0C`, Classical CAN, termination disabled, with no warnings.
- Trial 1 remains classified as an executor failure caused by the corrected decoder defect; its successful physical response and safe cleanup evidence remain unchanged. No corrected retry has run.

The retry is ready for fresh exact physical authorization.
